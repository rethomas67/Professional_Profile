import React from "react";

const Resume = () => {
  return <div>Resume</div>;
};

export default Resume;
